package unibo.springIntro23;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringIntro23Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringIntro23Application.class, args);
	}

}
